<?php
	global $ss_prefix;
	$class = array();
	$style = array();

	if ( !empty($layout3_grid_sizer) ) {
		$class[] = "ss-tile-grid-sizer";
	}
	if ( !empty($tiles_gallery_caption) ) {
		$class[] = "has-caption";
	}
	if ( !empty($tiles_gallery_always_hover) ) {
		$class[] = "only-hover";
	}

	$style[] = "background-color:" . $tiles_gallery_bg_color . ";";
	$style[] = "color:" . $tiles_gallery_text_color . ";";

	$html_class = implode(' ', $class);
	$html_style = implode(' ', $style);

	$thumbnail = rwmb_meta( "{$ss_prefix}portfolio_thumbnail",  "type=image&size=spnoy-mosaic-gallery-layout-2" );
	$thumbnail = array_shift($thumbnail);

?>
<div class="ss-tile has-layout-3 <?php echo $html_class; ?>" >

	<?php if ( !empty($tiles_gallery_complete_link) ) : ?>
	<a class="ss-tile-link" href="<?php echo $link_to; ?>">
	<?php endif; ?>
	
		<?php if ( empty($tiles_gallery_always_hover) ) : ?>
		<figure class="ss-tile-bg">
			<?php echo '<img src="' . $thumbnail['url'] . '" width="' . $thumbnail['width'] . '" height="' . $thumbnail['height'] . '" alt="' . $thumbnail['alt'] . '" />'; ?>
		</figure>
		<?php endif; ?>

		<?php if ( !empty($tiles_gallery_caption) ) : ?>
		<div class="ss-tile-caption valign">
			<span style="color: <?php echo $tiles_gallery_caption_color; ?>">
				<?php
					echo $tiles_gallery_caption;
				?>
			</span>
		</div>
		<?php endif; ?>

		<?php if ( !empty($tiles_gallery_hover) ) : ?>
		<div class="ss-tile-content" style="<?php echo $html_style; ?>">
			<span><?php echo $tiles_gallery_hover; ?></span>
			<?php if ( !empty($tiles_gallery_readmore) ) : ?>
			<a href="<?php echo $link_to; ?>" class="ss-tile-readmore">Read more</a>
			<?php endif; ?>
		</div>
		<?php endif; ?>

	<?php if ( !empty($tiles_gallery_complete_link) ) : ?>
	</a>
	<?php endif; ?>

</div>
